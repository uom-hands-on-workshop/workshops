# Contributors

## Workshop Content Creation

 - **[Dr Eduardo Oliveira](https://findanexpert.unimelb.edu.au/profile/653031-eduardo-araujo-oliveira)**, School of Computing and Information Systems.
 - **[Dr Shannon Rios](https://findanexpert.unimelb.edu.au/profile/985603-shannon-rios)**, FEIT Teaching and Learning Lab.
 - **Cory dal Ponte**, MDHS.

## Workshop Facilitators

 - **[Dr Eduardo Oliveira](https://findanexpert.unimelb.edu.au/profile/653031-eduardo-araujo-oliveira)**, School of Computing and Information Systems.
 - **[Dr Shannon Rios](https://findanexpert.unimelb.edu.au/profile/985603-shannon-rios)**, FEIT Teaching and Learning Lab.
 - **Cory dal Ponte**, MDHS.

## Reviewers

 - **[Prof. Jamie Evans](https://about.unimelb.edu.au/leadership/senior-leadership/provost/professor-jamie-evans)**
 - **[Dr Leah Schwartz](https://about.unimelb.edu.au/leadership/senior-leadership/provost/leah-schwartz)**
 - **Paul Barry**

You can contribute to our workshops as well. Please contact us [here](/afterword/collaborate).
